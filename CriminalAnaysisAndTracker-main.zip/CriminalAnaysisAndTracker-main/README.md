Below is a sex offender anaylsis for the state of california. It relates the price and density to a number of criminals.
The relationship between the datasets is still to be detirmined, but so far a positive coorelations has been
found between house prices and number of criminal, most likely becuase dense regions have a large number of offenders within 
a given radius.It is in CriminalAnalysis.ipynb
